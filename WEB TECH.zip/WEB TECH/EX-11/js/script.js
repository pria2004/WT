$(document).ready(function() {
    let taskId = 1;
    let totalTasks = 0;
    let completedTasks = 0;
  
    // Scroll to task section when "View Tasks" is clicked
    $('#view-task-btn').on('click', function() {
      $('html, body').animate({
        scrollTop: $('#task-section').offset().top
      }, 1000);
    });
  
    // Open modal when "Add Task" is clicked
    $('#add-task-btn').on('click', function() {
      $('#task-modal').fadeIn();
    });
  
    // Close modal
    $('#close-modal-btn').on('click', function() {
      $('#task-modal').fadeOut();
    });
  
    // Save task
    $('#save-task-btn').on('click', function() {
      let taskName = $('#task-name').val();
      let taskDesc = $('#task-desc').val();
      let taskDate = $('#task-date').val();
  
      if (taskName && taskDesc && taskDate) {
        let taskHtml = `
          <div class="task-card" id="task-${taskId}">
            <h3>${taskName}</h3>
            <p>${taskDesc}</p>
            <p>Due Date: ${taskDate}</p>
            <button class="complete-btn">Complete</button>
          </div>
        `;
        $('#task-container').append(taskHtml);
        $('#task-modal').fadeOut();
  
        // Clear input fields
        $('#task-name').val('');
        $('#task-desc').val('');
        $('#task-date').val('');
        taskId++;
        totalTasks++;
        updateProgress();
      }
    });
  
    // Mark task as completed
    $(document).on('click', '.complete-btn', function() {
      let taskCard = $(this).closest('.task-card');
      taskCard.addClass('completed');
  
      // Add delete button
      taskCard.append('<button class="delete-btn">Delete Task</button>');
      $(this).addClass('completed').text('Completed!');
  
      // Show Hurray message
      alert('Task completed! Hurray!');
      completedTasks++;
      updateProgress();
    });
  
    // Delete task
    $(document).on('click', '.delete-btn', function() {
      let taskCard = $(this).closest('.task-card');
      
      // Check if the task is completed, then reduce completedTasks
      if (taskCard.hasClass('completed')) {
        completedTasks--;
      }
      
      // Remove task and adjust totalTasks
      taskCard.fadeOut(function() {
        $(this).remove();
        totalTasks--;
        updateProgress();
      });
    });
  
    // Update the progress bar
    function updateProgress() {
      let progressPercentage = totalTasks === 0 ? 0 : (completedTasks / totalTasks) * 100;
      if (progressPercentage > 100) {
        progressPercentage = 100;  // Cap progress at 100%
      }
  
      // Update progress text and bar width
      $('#progress-text').text(`${Math.round(progressPercentage)}% Tasks Completed`);
      $('.progress-bar').css('width', `${progressPercentage}%`);
  
      // Change progress bar color based on completion percentage
      if (progressPercentage <= 30) {
        $('.progress-bar').css('background-color', '#e74c3c'); // Red
      } else if (progressPercentage <= 60) {
        $('.progress-bar').css('background-color', '#f39c12'); // Yellow
      } else {
        $('.progress-bar').css('background-color', '#2ecc71'); // Green
      }
    }
  });
  