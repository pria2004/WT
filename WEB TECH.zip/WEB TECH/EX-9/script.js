// Pagination for images
let currentIndex = 0;
const images = document.querySelectorAll('.photo');
const nextButton = document.querySelector('.next');
const prevButton = document.querySelector('.prev');

function showImage(index) {
  images.forEach((image, i) => {
    if (i === index) {
      image.style.display = 'block';
    } else {
      image.style.display = 'none';
    }
  });
}

nextButton.addEventListener('click', () => {
  currentIndex = (currentIndex + 1) % images.length;
  showImage(currentIndex);
});

prevButton.addEventListener('click', () => {
  currentIndex = (currentIndex - 1 + images.length) % images.length;
  showImage(currentIndex);
});

// Show the first image initially
showImage(currentIndex);
function scrollCarousel(direction) {
  const carousel = document.getElementById("carousel");
  const scrollAmount = carousel.offsetWidth * 0.6; // scroll 60% width

  if (direction === 1) {
    carousel.scrollBy({ left: scrollAmount, behavior: 'smooth' });
  } else {
    carousel.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
  }
}